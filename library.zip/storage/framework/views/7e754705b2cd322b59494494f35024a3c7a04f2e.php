

<?php $__env->startSection('title'); ?>
    Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form class="card p-3" method="POST" action="<?php echo e(route('books.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">

            <input type="text" name="title" class="form-control" value="<?php echo e(old('title')); ?>" placeholder="title">
        </div>

        <div class="form-group my-2">

            <textarea class="form-control" name="desc" placeholder="Description" rows="3"><?php echo e(old('desc')); ?></textarea>
        </div>
        <div class="form-group py-2">

            <input type="file" name="img" class="form-control-file">
        </div>
        <h3>Select Categories:</h3>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check mx-4 ">
                <input class="form-check-input" name="category_ids[]" value="<?php echo e($category->id); ?> " type="checkbox" id="<?php echo e($category->id); ?>">
                <label class="form-check-label " for="<?php echo e($category->id); ?>">
                    -<?php echo e($category->name); ?>

                </label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>
        <button type="submit" class="btn btn-primary m-2">Create</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/books/create.blade.php ENDPATH**/ ?>