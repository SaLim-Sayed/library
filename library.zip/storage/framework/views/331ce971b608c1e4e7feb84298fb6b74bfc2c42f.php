

<?php $__env->startSection('title'); ?>
    Create Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form method="POST" action="<?php echo e(route('categories.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">

            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="name">
        </div>


        <button type="submit" class="btn btn-primary mb-2">Create</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/categories/create.blade.php ENDPATH**/ ?>