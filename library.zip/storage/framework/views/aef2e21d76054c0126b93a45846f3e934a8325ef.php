

<?php $__env->startSection('title'); ?>
    Create Note
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form method="POST" action="<?php echo e(route('notes.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
       

        <div class="form-group my-2">

            <textarea class="form-control" name="content" placeholder="content" rows="3"><?php echo e(old('content')); ?></textarea>
        </div>
       
        <button type="submit" class="btn btn-primary mb-2">Create</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/notes/create.blade.php ENDPATH**/ ?>