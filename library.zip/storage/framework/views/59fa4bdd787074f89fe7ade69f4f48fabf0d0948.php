<nav class="navbar fixed-top  navbar-expand-lg navbar-light " style="background-color: #e3f2fd;font-family:cursive">
    <div class="container-fluid">
        <a class="navbar-brand active btn btn-outline-success" href="<?php echo e(route('auth.welcome')); ?>">Library >></a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link btn mx-2 btn-outline-success" href="<?php echo e(route('books.index')); ?>">All Books</a>
                </li>
                
                <div class="dropdown">
                    <button class="btn btn-outline-success mx-2 dropdown-toggle" type="button" id="dropdownMenuButton1"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo app('translator')->get('site.cats'); ?>
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li class="btn btn-success"><a class="dropdown-item btn btn-success" href="<?php echo e(route('categories.create')); ?> ">create new categories</a></li>
                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('categories.show',$cat->id)); ?> "><?php echo e($cat->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </ul>

            <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-success mx-2" href="<?php echo e(route('auth.register')); ?>">Register</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-primary mx-2" href="<?php echo e(route('auth.login')); ?>">Login</a>
                    </li>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>


                    <li class="nav-item">
                        <a href="#" class="nav-link disabled btn btn-outline-info mx-3"><?php echo e(Auth::user()->name); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-danger" href="<?php echo e(route('auth.logout')); ?>">Logout</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\library\resources\views/components/navbar.blade.php ENDPATH**/ ?>