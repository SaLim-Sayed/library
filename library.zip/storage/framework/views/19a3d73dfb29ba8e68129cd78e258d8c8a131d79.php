
<?php $__env->startSection('title'); ?>
    Show Book
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3 style="color: rgb(6, 58, 103) ; font-family:fantasy">Book ID: <?php echo e($book->id); ?></h3>

    <hr>
    <div class="card m-3">
        <div class="card" style="width: 25rem;">
            <h3 class="card-title bg-secondary"><?php echo e(ucwords($book->title)); ?></h3>
            <div class="row row-cols-1 row-cols-md-2">
                <div class="col mb-4">
                    <div class="card-body">
                        <p class="card-text"><?php echo e(ucwords($book->desc)); ?></p>
                        <hr>
                        <h3 class="card-title">Categories:</h3>
                        <ul>

                            <?php $__currentLoopData = $book->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($category->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col mb-4">
                    <?php if($book->img !== null): ?>
                        <img class="card-img-top" src="<?php echo e(asset('uploads/books/' . $book->img)); ?>" alt="no Img">
                    <?php else: ?>
                        <img class="card-img-top" style="flex: flex-end" src="<?php echo e(asset('uploads/books/noimage1.png')); ?>">
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">

                <a class="card-link btn btn-primary" href="<?php echo e(route('books.index')); ?>">Back</a>
                <a class="card-link btn btn-success" href="<?php echo e(route('books.edit', $book->id)); ?>">Edit Book</a>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->is_admin == 1): ?>
                        <a class="card-link btn btn-danger" href="<?php echo e(route('books.delete', $book->id)); ?>">Delete Book</a>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    </div>


    <hr>
    <a href="<?php echo e(route('books.index')); ?>">Back</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/books/show.blade.php ENDPATH**/ ?>