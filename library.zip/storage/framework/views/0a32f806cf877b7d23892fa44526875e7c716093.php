

<?php $__env->startSection('title'); ?>
    Register
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <form class="px-5" method="POST" action="<?php echo e(route('auth.handleRegister')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h2 class="title">Register</h2>
        <div class="form-group my-2">

            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="name">
        </div>
        <div class="form-group my-2">

            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="email">
        </div>
        <div class="form-group my-2">

            <input type="password" name="password" class="form-control" value="<?php echo e(old('password')); ?>"
                placeholder="password">
        </div>
        

        <div class="card-body">
            <button type="submit" class="btn btn-primary mb-2">Sign Up</button> OR
            <a class="btn btn-outline-success" href="<?php echo e(route('auth.github.redirect')); ?> ">Sign Up With Github</a>

            <br>
            <span class="" style="padding-left:70%">

                <a class="btn btn-outline-danger "
                    href="<?php echo e(route('auth.login')); ?>"><?php echo e(ucwords('you already have an account | login')); ?></a>


            </span>
        </div>

    </form>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/auth/register.blade.php ENDPATH**/ ?>