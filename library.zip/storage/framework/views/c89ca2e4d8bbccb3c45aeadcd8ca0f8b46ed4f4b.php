
<?php $__env->startSection('title'); ?>
    Show Category
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h3 style="color: rgb(6, 58, 103) ; font-family:fantasy">Category ID: <?php echo e($category->id); ?></h3>

    <hr>
    <div class="card m-3">
        <div class="card" style="width: 30rem;">

            <div class="col">
                <div class="card">

                    <h3 class="card-title btn btn-secondary"><?php echo e(ucwords($category->name)); ?></h3>
                    <h3 class="card-title">Books:</h3>
                    <ul>

                        <?php $__currentLoopData = $category->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($book->title); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="card-body">

                <a class="card-link" href="<?php echo e(route('categories.index')); ?>">
                    <button type="submit" class="btn btn-primary">Back</button>
                </a>
                <a class="card-link" href="<?php echo e(route('categories.edit', $category->id)); ?>">
                    <button type="submit" class="btn btn-success">Edit Category</button>
                </a>
                <a class="card-link" href="<?php echo e(route('categories.delete', $category->id)); ?>">
                    <button type="submit" class="btn btn-danger">Delete Category</button>
                </a>

            </div>
        </div>
    </div>


    <hr>
    <a href="<?php echo e(route('categories.index')); ?>">Back</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/categories/show.blade.php ENDPATH**/ ?>