

<?php $__env->startSection('title'); ?>
    Welcome
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="">
        <?php if(auth()->guard()->check()): ?>
            <h2 style="font-family:serif" class=" bg-dark text-light text-center nav-link btn btn-outline-info">
                Welcome <span style="font-family:cursive;color:aqua">"<?php echo e(Auth::user()->name); ?>" </span> in Our Library

                <img class="card-img" src="<?php echo e(asset('uploads/library.png')); ?>" alt="">
            </h2>
        <?php endif; ?>
        <?php if(auth()->guard()->guest()): ?>
            <h5 class=" bg-dark text-light text-center nav-link btn btn-outline-info">
                <a href="<?php echo e(route('auth.login')); ?>">Join to Our Library</a>
                <img class="card-img" src="<?php echo e(asset('uploads/library.png')); ?>" alt="">
            </h5>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/auth/welcome.blade.php ENDPATH**/ ?>