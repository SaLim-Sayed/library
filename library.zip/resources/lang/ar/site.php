<?php
return [
    'books'=>'الكتب',
    'cats'=>'Categories',
    'logout'=>'Logout',
];