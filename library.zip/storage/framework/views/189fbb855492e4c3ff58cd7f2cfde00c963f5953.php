<?php $__env->startSection('title'); ?>
    All Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>All Categories</h1>

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <hr>


        <div class="card" style="width: 30rem;">

            <div class="col mb-4">
                <div class="card-body">
                    <h3 class="card-title"> <a class="card-link" href="<?php echo e(route('categories.show', $category->id)); ?>">
                            <?php echo e(ucwords($category->name)); ?>

                        </a>
                    </h3>

                </div>
            </div>


            <div class="card-body">

                <a class="card-link btn btn-primary" href="<?php echo e(route('categories.show', $category->id)); ?>">Show Category </a>
                <a class="card-link btn btn-success" href="<?php echo e(route('categories.edit', $category->id)); ?>">Edit Category</a>
                <a class="card-link btn btn-danger" href="<?php echo e(route('categories.delete', $category->id)); ?>">Delete Category</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <hr>
    <button type="submit" class=" btn btn-primary mb-2"><a class="text-light"
            href="<?php echo e(route('categories.create')); ?>">Creete</a></button>

    <hr>

    <?php echo e($categories->render()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/categories/index.blade.php ENDPATH**/ ?>