<?php
return [
    'books'=>'Books',
    'cats'=>'Categories',
    'logout'=>'Logout',
];