<?php $__env->startSection('title'); ?>
    All Books
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php if(auth()->guard()->check()): ?>
    <div class="card bg-success m-2 p-2">
        <input type="text" class="container   form-control" placeholder="Search for a Book" style="width: 50rem;" id="keyword">
    </div>
        

    <?php endif; ?>
   
    <div class="card" id="allBooks">
        <?php if(auth()->guard()->check()): ?>
        <div class="card  m-2 p-2">

            <h1 style="color: rgb(6, 58, 103) ; font-family:cursive">Notes:</h1>
            <ul>
                <?php $__currentLoopData = Auth::user()->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e(ucwords($note->content)); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <a href="<?php echo e(route('notes.create')); ?> "style="width: 50rem;" class=" container btn btn-info">Add new note</a>
        </div>
        <?php endif; ?>
        
        <?php if(auth()->guard()->check()): ?>
            
        <?php endif; ?>
        <h1><span style="color: rgb(6, 58, 103) ; font-family:fantasy"> All Books: </span>
            <a class="  btn btn-primary mb-2" style="width: 20rem;margin-left:470px" href="<?php echo e(route('books.create')); ?>">Creete New Book</a>
        </h1>
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
         <div class="card container my-2" style="width: 50rem;">
                <a class="btn btn-secondary" href="<?php echo e(route('books.show', $book->id)); ?>">
                    <?php echo e(ucwords($book->title)); ?>

                </a>


                <div class="row row-cols-1 row-cols-md-2">
                    <div class="col mb-4">
                        <div class="card-body">

                            <p class="card-text"><?php echo e(ucwords($book->desc)); ?></p>
                        </div>
                    </div>
                    <div class="col ">
                        <?php if($book->img !== null): ?>
                            <img class="card-img-top" src="<?php echo e(asset('uploads/books/' . $book->img)); ?>" alt="no Img"
                                style="">
                        <?php else: ?>
                            <img style="flex: flex-end" class="card-img-top "
                                src="<?php echo e(asset('uploads/books/noimage1.png')); ?>" alt="no Img"
                                style="width: 100px; height: 100px;">
                        <?php endif; ?>
                    </div>
                </div>

                <div class=" card-body">
                    <a class="btn btn-primary" href="<?php echo e(route('books.show', $book->id)); ?>"> Show Book</a>
                    <a class="  btn btn-success" href="<?php echo e(route('books.edit', $book->id)); ?>">Edit Book</a>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(Auth::user()->is_admin == 1): ?>
                            <a class="btn btn-danger" href="<?php echo e(route('books.delete', $book->id)); ?>"> Delete Book</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <hr>

    <hr>

    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('#keyword').keyup(function() {
            let keyword = $(this).val()
            let url = "<?php echo e(route('books.search')); ?>" + "?keyword=" + keyword

            $.ajax({
                type: "GET",
                url: url,
                contentType: false,
                processData: false,
                success: function(data) {

                    $('#allBooks').empty()
                    for (book of data) {
                        // console.log(book.id, book.title)
                        $('#allBooks').append(`
                        <h5 style="color: rgb(6, 58, 103) ; font-family:fantasy"> Book ID :${book.id}</h5>
                             <div class="card container" style="width: 50rem;">
                                <h3 class="btn btn-secondary">${book.title}</h3>
                                <div class="row row-cols-1 row-cols-md-2">
                                    <div class="col mb-4">
                                        <div class="card-body">
                                            <p class="card-text">${book.desc}</p>
                                        </div>
                                    </div>
                                    <div class="col ">
                                        <img class="card-img-top" src="<?php echo e(asset('uploads/books/${book.img}')); ?>">
                                    </div>
                                </div>
                                <div class=" card-body">
                                    <a class="btn btn-primary" href="<?php echo e(route('books.show', $book->id)); ?>"> Show Book</a>
                                    <a class="  btn btn-success" href="<?php echo e(route('books.edit', $book->id)); ?>">Edit Book</a>
                                    <?php if(auth()->guard()->check()): ?>
                                        <?php if(Auth::user()->is_admin == 1): ?>
                                            <a class="btn btn-danger" href="<?php echo e(route('books.delete', $book->id)); ?>"> Delete Book</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                                <hr />
                            </div>
          `)
                    }
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\library\resources\views/books/index.blade.php ENDPATH**/ ?>